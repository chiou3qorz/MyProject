from distutils.core import setup

setup(
    name = 'MyProject',
    packages = ['mypackage'],
    scripts = [],
    version = '1.0',
    description = 'My first project',
    author = 'chiou',
    author_email = 'chiou@e-happy.com.tw',
    url = 'https://github.com/chiou3qorz/MyProject.git',
    download_url = 'https://github.com/chiou3qorz/MyProject/tarball/v1.0',
    keywords = ['Good Project'],
    classifiers = [],
)